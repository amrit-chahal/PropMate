import InformationChip  from './informationChip';
export default InformationChip;
