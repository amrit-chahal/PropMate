import LocationCard from './locationCard';
export default LocationCard;
